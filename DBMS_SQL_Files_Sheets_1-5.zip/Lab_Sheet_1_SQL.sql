-- Lab Sheet 1 — DDL Commands
-- MySQL solutions for Lab Sheet 1 — DDL Commands.
-- Important: multiple questions create tables with the same names. Run each numbered task separately; do not run all CREATE TABLE statements consecutively without resetting/renaming tables.

CREATE DATABASE IF NOT EXISTS CollegeDB;
USE CollegeDB;

-- 1. Create database
CREATE DATABASE CollegeDB; USE CollegeDB;

-- 2. Create Student
CREATE TABLE Student (Student_ID INT, Name VARCHAR(100), Age INT, Course VARCHAR(50), City VARCHAR(50));

-- 3. Create Employee
CREATE TABLE Employee (Emp_ID INT, Emp_Name VARCHAR(100), Department VARCHAR(50), Salary DECIMAL(10,2));

-- 4. Create Department
CREATE TABLE Department (Dept_ID INT, Dept_Name VARCHAR(100), Location VARCHAR(100));

-- 5. Create Product
CREATE TABLE Product (Product_ID INT, Product_Name VARCHAR(100), Price DECIMAL(10,2), Quantity INT);

-- 6. Create Customer
CREATE TABLE Customer (Customer_ID INT, Customer_Name VARCHAR(100), Email VARCHAR(100), Phone VARCHAR(20));

-- 7. Create Course
CREATE TABLE Course (Course_ID INT, Course_Name VARCHAR(100), Duration VARCHAR(30), Fees DECIMAL(10,2));

-- 8. Create Faculty
CREATE TABLE Faculty (Faculty_ID INT, Faculty_Name VARCHAR(100), Subject VARCHAR(50), Salary DECIMAL(10,2));

-- 9. Create Library
CREATE TABLE Library (Book_ID INT, Book_Name VARCHAR(150), Author VARCHAR(100), Price DECIMAL(10,2));

-- 10. Department with primary key
CREATE TABLE Department (Dept_ID INT PRIMARY KEY, Dept_Name VARCHAR(100), Location VARCHAR(100));

-- 11. Student with primary key and NOT NULL
CREATE TABLE Student (Student_ID INT PRIMARY KEY, Name VARCHAR(100) NOT NULL, Age INT, Course VARCHAR(50), City VARCHAR(50));

-- 12. Employee with UNIQUE email
CREATE TABLE Employee (Emp_ID INT PRIMARY KEY, Emp_Name VARCHAR(100), Email VARCHAR(100) UNIQUE, Department VARCHAR(50), Salary DECIMAL(10,2));

-- 13. Product with CHECK
CREATE TABLE Product (Product_ID INT PRIMARY KEY, Product_Name VARCHAR(100), Price DECIMAL(10,2) CHECK (Price > 0), Quantity INT);

-- 14. Add Email
ALTER TABLE Student ADD Email VARCHAR(100);

-- 15. Add Phone
ALTER TABLE Student ADD Phone VARCHAR(20);

-- 16. Modify Name size
ALTER TABLE Student MODIFY Name VARCHAR(150);

-- 17. Rename Student table
RENAME TABLE Student TO Student_Details;

-- 18. Rename City to Address
ALTER TABLE Student CHANGE City Address VARCHAR(50);

-- 19. Add Salary
ALTER TABLE Employee ADD Salary DECIMAL(10,2);

-- 20. Drop Phone
ALTER TABLE Student DROP COLUMN Phone;

-- 21. Drop Email
ALTER TABLE Student DROP COLUMN Email;

-- 22. Truncate table
TRUNCATE TABLE Student;

-- 23. Drop Course
DROP TABLE Course;

-- 24. Drop Customer
DROP TABLE Customer;

-- 25. Complete Student constraints and ALTER/DROP
CREATE TABLE Student (Student_ID INT PRIMARY KEY, Name VARCHAR(100) NOT NULL, Email VARCHAR(100) UNIQUE, Age INT CHECK (Age >= 16), Course VARCHAR(50)); ALTER TABLE Student ADD City VARCHAR(50); ALTER TABLE Student DROP COLUMN City;
