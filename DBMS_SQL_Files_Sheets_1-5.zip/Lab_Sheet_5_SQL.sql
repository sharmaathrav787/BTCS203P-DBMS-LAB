-- Lab Sheet 5 — SQL Joins
-- MySQL solutions for Lab Sheet 5 — SQL Joins.
-- These queries assume Student.Dept_ID, Student.Course_ID, Employee.Dept_ID, and Employee.Manager_ID exist. Add appropriate columns and sample data before running those tasks.

CREATE DATABASE IF NOT EXISTS CollegeDB;
USE CollegeDB;

-- 1. INNER JOIN Student/Department
SELECT s.Student_ID,s.Name,d.Dept_Name FROM Student s INNER JOIN Department d ON s.Dept_ID=d.Dept_ID;

-- 2. Student and department names
SELECT s.Name,d.Dept_Name FROM Student s INNER JOIN Department d ON s.Dept_ID=d.Dept_ID;

-- 3. Employee and department names
SELECT e.Emp_Name,d.Dept_Name FROM Employee e INNER JOIN Department d ON e.Dept_ID=d.Dept_ID;

-- 4. Students with course details
SELECT s.Name,c.Course_Name,c.Duration,c.Fees FROM Student s INNER JOIN Course c ON s.Course_ID=c.Course_ID;

-- 5. Students in IT department
SELECT s.Name,d.Dept_Name FROM Student s JOIN Department d ON s.Dept_ID=d.Dept_ID WHERE d.Dept_Name='IT';

-- 6. LEFT OUTER JOIN
SELECT s.Name,d.Dept_Name FROM Student s LEFT JOIN Department d ON s.Dept_ID=d.Dept_ID;

-- 7. All students even without department
SELECT s.*,d.Dept_Name FROM Student s LEFT JOIN Department d ON s.Dept_ID=d.Dept_ID;

-- 8. RIGHT OUTER JOIN
SELECT s.Name,d.Dept_Name FROM Student s RIGHT JOIN Department d ON s.Dept_ID=d.Dept_ID;

-- 9. All departments including empty ones
SELECT d.Dept_ID,d.Dept_Name,s.Name FROM Department d LEFT JOIN Student s ON s.Dept_ID=d.Dept_ID;

-- 10. Students with no department match
SELECT s.* FROM Student s LEFT JOIN Department d ON s.Dept_ID=d.Dept_ID WHERE d.Dept_ID IS NULL;

-- 11. Departments with no students
SELECT d.* FROM Department d LEFT JOIN Student s ON s.Dept_ID=d.Dept_ID WHERE s.Student_ID IS NULL;

-- 12. FULL OUTER JOIN workaround
SELECT s.Name,d.Dept_Name FROM Student s LEFT JOIN Department d ON s.Dept_ID=d.Dept_ID UNION SELECT s.Name,d.Dept_Name FROM Student s RIGHT JOIN Department d ON s.Dept_ID=d.Dept_ID;

-- 13. CROSS JOIN
SELECT s.Name,c.Course_Name FROM Student s CROSS JOIN Course c;

-- 14. Count all combinations
SELECT COUNT(*) AS Total_Combinations FROM Student CROSS JOIN Course;

-- 15. NATURAL JOIN
SELECT * FROM Student NATURAL JOIN Department;

-- 16. Compare NATURAL and INNER JOIN
SELECT * FROM Student NATURAL JOIN Department; SELECT s.Student_ID,s.Name,d.Dept_Name FROM Student s JOIN Department d ON s.Dept_ID=d.Dept_ID;

-- 17. SELF JOIN employee-manager
SELECT e.Emp_Name AS Employee,m.Emp_Name AS Manager FROM Employee e LEFT JOIN Employee m ON e.Manager_ID=m.Emp_ID;

-- 18. Employees with manager names
SELECT e.Emp_ID,e.Emp_Name,m.Emp_Name AS Manager_Name FROM Employee e LEFT JOIN Employee m ON e.Manager_ID=m.Emp_ID;

-- 19. Join Student, Department, Course
SELECT s.Name,d.Dept_Name,c.Course_Name FROM Student s JOIN Department d ON s.Dept_ID=d.Dept_ID JOIN Course c ON s.Course_ID=c.Course_ID;

-- 20. Student/course/department report
SELECT s.Name AS Student_Name,c.Course_Name,d.Dept_Name FROM Student s LEFT JOIN Course c ON s.Course_ID=c.Course_ID LEFT JOIN Department d ON s.Dept_ID=d.Dept_ID;

-- 21. Salary above department average
SELECT e.Emp_Name,e.Salary,d.Dept_Name FROM Employee e JOIN Department d ON e.Dept_ID=d.Dept_ID WHERE e.Salary>(SELECT AVG(e2.Salary) FROM Employee e2 WHERE e2.Dept_ID=e.Dept_ID);

-- 22. Department with most students
SELECT d.Dept_ID,d.Dept_Name,COUNT(s.Student_ID) AS Student_Count FROM Department d LEFT JOIN Student s ON s.Dept_ID=d.Dept_ID GROUP BY d.Dept_ID,d.Dept_Name ORDER BY Student_Count DESC LIMIT 1;

-- 23. Count students per department
SELECT d.Dept_Name,COUNT(s.Student_ID) AS Student_Count FROM Department d LEFT JOIN Student s ON s.Dept_ID=d.Dept_ID GROUP BY d.Dept_ID,d.Dept_Name;

-- 24. Count students per course
SELECT c.Course_Name,COUNT(s.Student_ID) AS Enrolled_Students FROM Course c LEFT JOIN Student s ON s.Course_ID=c.Course_ID GROUP BY c.Course_ID,c.Course_Name;

-- 25. Complete grouped report
SELECT d.Dept_Name,c.Course_Name,COUNT(s.Student_ID) AS Student_Count FROM Department d LEFT JOIN Student s ON s.Dept_ID=d.Dept_ID LEFT JOIN Course c ON s.Course_ID=c.Course_ID GROUP BY d.Dept_ID,d.Dept_Name,c.Course_ID,c.Course_Name;

-- Important notes
-- Run CREATE DATABASE CollegeDB; then USE CollegeDB; before creating tables.
-- Lab Sheet 1 repeats table names across separate questions. Do not run every CREATE TABLE statement consecutively without dropping or renaming existing tables.
-- Lab Sheet 3 question 25 requires Employee.Joining_Date. Add it if needed: ALTER TABLE Employee ADD Joining_Date DATE;
-- Lab Sheet 5 assumes Student.Dept_ID, Student.Course_ID, Employee.Dept_ID, and Employee.Manager_ID exist. Add appropriate columns and sample data before running those joins.
-- MySQL has no direct FULL OUTER JOIN in common versions; UNION of LEFT and RIGHT JOIN is the workaround. INTERSECT/EXCEPT examples use join/NOT EXISTS workarounds.
-- Use SELECT * FROM Student; to display table contents.
