-- Lab Sheet 2 — DML Commands
-- MySQL solutions for Lab Sheet 2 — DML Commands.
-- These tasks assume the relevant tables/columns exist and may need sample tables/data. Run numbered tasks separately when necessary.

CREATE DATABASE IF NOT EXISTS CollegeDB;
USE CollegeDB;

-- 1. Insert one student
INSERT INTO Student (Student_ID,Name,Age,Course,City) VALUES (1,'Aman',19,'AI&ML','Roorkee');

-- 2. Insert five separately
INSERT INTO Student VALUES (1,'Aman',19,'AI&ML','Roorkee'); INSERT INTO Student VALUES (2,'Riya',20,'CSE','Delhi'); INSERT INTO Student VALUES (3,'Karan',18,'AI&ML','Meerut'); INSERT INTO Student VALUES (4,'Neha',19,'IT','Haridwar'); INSERT INTO Student VALUES (5,'Raj',21,'CSE','Delhi');

-- 3. Insert multiple rows
INSERT INTO Student VALUES (6,'Simran',19,'CSE','Delhi'),(7,'Dev',20,'IT','Roorkee');

-- 4. Insert employees
INSERT INTO Employee (Emp_ID,Emp_Name,Department,Salary) VALUES (101,'Amit','IT',45000),(102,'Neha','HR',40000);

-- 5. Insert departments
INSERT INTO Department VALUES (1,'IT','Roorkee'),(2,'HR','Delhi');

-- 6. Insert products
INSERT INTO Product VALUES (1,'Keyboard',800,10),(2,'Mouse',400,0);

-- 7. Insert customers
INSERT INTO Customer VALUES (1,'Asha','asha@example.com','9876543210');

-- 8. Insert courses
INSERT INTO Course VALUES (1,'AI&ML','4 years',120000),(2,'CSE','4 years',110000);

-- 9. Insert all student columns
INSERT INTO Student (Student_ID,Name,Age,Course,City) VALUES (8,'Ishita',19,'AI&ML','Roorkee');

-- 10. Insert selected columns
INSERT INTO Student (Student_ID,Name) VALUES (9,'Mohit');

-- 11. Update student city
UPDATE Student SET City='Delhi' WHERE Student_ID=1;

-- 12. Update employee salary
UPDATE Employee SET Salary=50000 WHERE Emp_ID=101;

-- 13. Increase salaries 10%
UPDATE Employee SET Salary=Salary*1.10;

-- 14. Increase product prices 5%
UPDATE Product SET Price=Price*1.05;

-- 15. Change student course
UPDATE Student SET Course='CSE' WHERE Student_ID=2;

-- 16. Update employee department
UPDATE Employee SET Department='Finance' WHERE Emp_ID=102;

-- 17. Meerut students to Delhi
UPDATE Student SET City='Delhi' WHERE City='Meerut';

-- 18. Update course fees
UPDATE Course SET Fees=125000 WHERE Course_ID=1;

-- 19. Update multiple columns
UPDATE Student SET Age=20, Course='AI&ML', City='Roorkee' WHERE Student_ID=3;

-- 20. Delete student by ID
DELETE FROM Student WHERE Student_ID=9;

-- 21. Delete students from a city
DELETE FROM Student WHERE City='Delhi';

-- 22. Delete employees below salary
DELETE FROM Employee WHERE Salary<30000;

-- 23. Delete products with zero quantity
DELETE FROM Product WHERE Quantity=0;

-- 24. Delete with AND/OR
DELETE FROM Student WHERE (City='Delhi' AND Age<20) OR Course='IT';

-- 25. INSERT, UPDATE, DELETE and display
INSERT INTO Student VALUES (20,'Test Student',19,'CSE','Roorkee'); SELECT * FROM Student; UPDATE Student SET City='Delhi' WHERE Student_ID=20; SELECT * FROM Student; DELETE FROM Student WHERE Student_ID=20; SELECT * FROM Student;
