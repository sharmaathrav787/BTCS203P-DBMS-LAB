DBMS Lab Sheets 1-5 SQL Files

These MySQL-oriented SQL files are based on the supplied SQL Lab Sheets 1-5 Solutions document.

Before running:
- Read the comments at the top of each file.
- Run questions one at a time; many questions reuse table names and depend on different table structures.
- Lab Sheet 3 Question 25 needs Employee.Joining_Date.
- Lab Sheet 5 joins assume Student.Dept_ID, Student.Course_ID, Employee.Dept_ID, and Employee.Manager_ID exist.
- Some tasks require sample data or earlier tables.

For practice/reference; check your teacher's exact requirements and test queries in your lab environment.
