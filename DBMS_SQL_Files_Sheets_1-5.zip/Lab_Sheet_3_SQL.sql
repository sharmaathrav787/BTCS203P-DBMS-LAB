-- Lab Sheet 3 — SQL Functions
-- MySQL solutions for Lab Sheet 3 — SQL Functions.
-- Question 25 requires Employee.Joining_Date. If missing, run: ALTER TABLE Employee ADD Joining_Date DATE;

CREATE DATABASE IF NOT EXISTS CollegeDB;
USE CollegeDB;

-- 1. ABS()
SELECT ABS(-25);

-- 2. ROUND()
SELECT ROUND(12.567,2);

-- 3. CEIL and FLOOR
SELECT CEIL(4.2), FLOOR(4.8);

-- 4. MOD()
SELECT MOD(17,5);

-- 5. Rounded employee salary
SELECT Emp_Name, ROUND(Salary,0) FROM Employee;

-- 6. COUNT students
SELECT COUNT(*) AS Total_Students FROM Student;

-- 7. SUM salaries
SELECT SUM(Salary) AS Total_Salary FROM Employee;

-- 8. AVG salary
SELECT AVG(Salary) AS Average_Salary FROM Employee;

-- 9. MAX salary
SELECT MAX(Salary) AS Highest_Salary FROM Employee;

-- 10. MIN salary
SELECT MIN(Salary) AS Lowest_Salary FROM Employee;

-- 11. UPPER names
SELECT Name, UPPER(Name) FROM Student;

-- 12. LOWER names
SELECT Name, LOWER(Name) FROM Student;

-- 13. LENGTH names
SELECT Name, LENGTH(Name) FROM Student;

-- 14. CONCAT first and last names
SELECT CONCAT('Athrav',' ','Sharma') AS Full_Name;

-- 15. SUBSTRING
SELECT SUBSTRING('Database',1,4);

-- 16. Number to string
SELECT CAST(12345 AS CHAR);

-- 17. String to number
SELECT CAST('123.45' AS DECIMAL(10,2));

-- 18. Format date
SELECT DATE_FORMAT('2026-10-12','%d-%m-%Y');

-- 19. CAST example
SELECT CAST(99.75 AS SIGNED);

-- 20. CONVERT example
SELECT CONVERT('2026-10-12', DATE);

-- 21. Current date
SELECT CURDATE();

-- 22. Extract year/month/day
SELECT YEAR('2026-10-12'), MONTH('2026-10-12'), DAY('2026-10-12');

-- 23. Difference between dates
SELECT DATEDIFF('2026-10-12','2026-10-01');

-- 24. Add days to date
SELECT DATE_ADD('2026-10-12', INTERVAL 10 DAY);

-- 25. Format joining date (requires Joining_Date column)
SELECT Emp_Name, DATE_FORMAT(Joining_Date,'%d-%m-%Y') FROM Employee;
