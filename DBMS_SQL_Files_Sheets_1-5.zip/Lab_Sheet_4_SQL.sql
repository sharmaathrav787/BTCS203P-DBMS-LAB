-- Lab Sheet 4 — SQL Operators
-- MySQL solutions for Lab Sheet 4 — SQL Operators.
-- Some set operators differ by MySQL version; use the workaround provided in the solution.

CREATE DATABASE IF NOT EXISTS CollegeDB;
USE CollegeDB;

-- 1. Addition
SELECT 10+5;

-- 2. Subtraction
SELECT 10-5;

-- 3. Multiplication
SELECT 10*5;

-- 4. Division
SELECT 10/5;

-- 5. Price times quantity
SELECT Product_Name, Price*Quantity AS Total_Amount FROM Product;

-- 6. AND
SELECT * FROM Student WHERE Course='CSE' AND City='Delhi';

-- 7. OR
SELECT * FROM Student WHERE City='Delhi' OR City='Roorkee';

-- 8. NOT
SELECT * FROM Student WHERE NOT City='Delhi';

-- 9. Specific course AND city
SELECT * FROM Student WHERE Course='AI&ML' AND City='Roorkee';

-- 10. Either of two departments
SELECT * FROM Employee WHERE Department IN ('IT','HR');

-- 11. Equal
SELECT * FROM Student WHERE City='Delhi';

-- 12. Greater than
SELECT * FROM Employee WHERE Salary>40000;

-- 13. Less than
SELECT * FROM Employee WHERE Salary<40000;

-- 14. >= and <=
SELECT * FROM Employee WHERE Salary>=30000 AND Salary<=60000;

-- 15. Not equal
SELECT * FROM Student WHERE Course<>'CSE';

-- 16. BETWEEN
SELECT * FROM Employee WHERE Salary BETWEEN 30000 AND 60000;

-- 17. IN
SELECT * FROM Student WHERE City IN ('Delhi','Roorkee');

-- 18. NOT IN
SELECT * FROM Student WHERE City NOT IN ('Delhi','Roorkee');

-- 19. LIKE names beginning A
SELECT * FROM Student WHERE Name LIKE 'A%';

-- 20. IS NULL / IS NOT NULL
SELECT * FROM Student WHERE City IS NULL; SELECT * FROM Student WHERE City IS NOT NULL;

-- 21. UNION
SELECT City AS Place FROM Student UNION SELECT Location AS Place FROM Department;

-- 22. UNION ALL
SELECT City AS Place FROM Student UNION ALL SELECT Location AS Place FROM Department;

-- 23. INTERSECT workaround
SELECT DISTINCT s.City FROM Student s JOIN Department d ON s.City=d.Location;

-- 24. EXCEPT workaround
SELECT DISTINCT s.City FROM Student s WHERE NOT EXISTS (SELECT 1 FROM Department d WHERE d.Location=s.City);

-- 25. Multiple operators
SELECT * FROM Product WHERE Price>100 AND Quantity BETWEEN 1 AND 20 AND Product_Name LIKE '%o%' AND Product_ID NOT IN (99,100);
